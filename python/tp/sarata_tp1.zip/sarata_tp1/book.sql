\c template1
drop database "GestionLivre";
create database "GestionLivre";
\c "GestionLivre"
